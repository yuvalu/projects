This project was done by: Tal Avraham, Omer Hagage, Fidaa naaffa, Yuval Ussishkin

File List :
classifier.py - Runs the predictions for both the crime labels and the crimes.
README - This file.
project.pdf -Project details and plots.
_jclusters.json - Contains the clusters for which we use to predict the crimes.
Preprocessing.py - Handles all of the preprocessing.

Please see pdf for further information about the project.
Link: https://github.com/talavr1112/IML-HACKATHON/blob/main/task2/project.pdf

